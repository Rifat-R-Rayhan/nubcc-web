

<?php $__env->startSection('content'); ?>
<main id="main">



<section style="background-color: #eee;">

    
    

    <div class="container py-5">
        <p class="text-muted display-6">Welcome To Your Profile!</p>
        <div class="row">
            <div class="col-lg-4">
                <div class="card mb-4" style="background:linear-gradient(#7F00FF,#E100FF);">
                    <div class="card-body text-center">
                    <img src="<?php echo e(asset('uploads/images/users')); ?>/<?php echo e($data->image); ?>" style="width: 160px; height: 160px; border-radius: 50%; border:4px solid white;">
                        <h5 class="my-3 text-white"><?php echo e($data->username); ?></h5>
                    </div>
                </div>
            </div>
            <div class="col-lg-8">
                <div class="card mb-4">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-sm-3">
                                <p class="mb-0">Full Name</p>
                            </div>
                            <div class="col-sm-9">
                                <p class="text-muted mb-0"><?php echo e($data->username); ?></p>
                            </div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-sm-3">
                                <p class="mb-0">Email</p>
                            </div>
                            <div class="col-sm-9">
                                <p class="text-muted mb-0"><?php echo e($data->email); ?></p>
                            </div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-sm-3">
                                <p class="mb-0">Program</p>
                            </div>
                            <div class="col-sm-9">
                                <p class="text-muted mb-0"><?php echo e($data->program); ?></p>
                            </div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-sm-3">
                                <p class="mb-0">Student ID</p>
                            </div>
                            <div class="col-sm-9">
                                <p class="text-muted mb-0"><?php echo e($data->student_id); ?></p>
                            </div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-sm-3">
                                <p class="mb-0">Semester</p>
                            </div>
                            <div class="col-sm-9">
                                <p class="text-muted mb-0"><?php echo e($data->semester); ?></p>
                            </div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-sm-3">
                                <p class="mb-0">Section</p>
                            </div>
                            <div class="col-sm-9">
                                <p class="text-muted mb-0"><?php echo e($data->section); ?></p>
                            </div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-sm-3">
                                <p class="mb-0">Contact</p>
                            </div>
                            <div class="col-sm-9">
                                <p class="text-muted mb-0"><?php echo e($data->contact); ?></p>
                            </div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-sm-3">
                                <p class="mb-0">Blood Group</p>
                            </div>
                            <div class="col-sm-9">
                                <p class="text-muted mb-0"><?php echo e($data->blood_group); ?></p>
                            </div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-sm-3">
                                <p class="mb-0">Present Address</p>
                            </div>
                            <div class="col-sm-9">
                                <p class="text-muted mb-0"><?php echo e($data->present_address); ?></p>
                            </div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-sm-3">
                                <p class="mb-0">Permanent Address</p>
                            </div>
                            <div class="col-sm-9">
                                <p class="text-muted mb-0"><?php echo e($data->permanent_address); ?></p>
                            </div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-sm-3">
                                <p class="mb-0">Action</p>
                            </div>
                            <div class="col-sm-9">
                                

                                <form action="<?php echo e(route('user-edit')); ?>" method="get">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="id" value="<?php echo e($data->id); ?>">
                                    <div class="">
                                        <button class="btn btn-success d-inline-block" type="submit"><i class="bx bx-edit-alt me-1"></i> UPDATE</button>
                                    </div>
                                    
                                </form>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>




</main><!-- End #main -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('client.layouts.masterlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nubcc-web\resources\views/client/pages/userDashboard.blade.php ENDPATH**/ ?>