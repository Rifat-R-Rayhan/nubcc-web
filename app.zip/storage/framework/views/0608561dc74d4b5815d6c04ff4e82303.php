    <!-- ======= Why Us Section ======= -->
    <section class="why-us section-bg mt-5" data-aos="fade-up" date-aos-delay="200">
        <div class="container">

            <div class="row">
                <div class="col-lg-6 video-box">
                    <img src="img/video_thumbnail_1.jpg" class="img-fluid" alt="">
                    <a href="https://www.youtube.com/watch?v=dmexsRp9zxk" target="_blank" class="venobox play-btn mb-4" data-vbtype="video" data-autoplay="true"></a>
                </div>

                <div class="col-lg-6 d-flex flex-column justify-content-center p-3">


                    <h4 class="title">Our Community</h4>
                    <p class="description text-justify"><strong>Northern University Bangladesh (NUB)</strong> is a renowned name
                        among the Universities of Bangladesh.
                        <br><br>
                        It has passed 20 years with immense success and so has the department of Computer Science and Engineering
                        (CSE). This department is a place for fostering skilled professionals.
                    </p>




                </div>
            </div>

        </div>
    </section><!-- End Why Us Section --><?php /**PATH C:\xampp\htdocs\nubcc-web\resources\views/client/components/community.blade.php ENDPATH**/ ?>