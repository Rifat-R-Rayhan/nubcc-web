<?php $__env->startSection('content'); ?>
<main id="main">


<!-- ======= T-Shirt Section ======= -->
<section id="blog" class="blog">
   

        <!-- Project Start -->
        <div class="container-xxl py-2">
            <div class="container my-5">
                <div class="my-5 py-5 text-center mx-auto mb-0 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 600px;">
                    <img src="assets/img/cracker.png" alt="" width="150px">
                    <h6 class="text-center text-primary px-3">Congratulations!</h6>
                    <h3 class="display-7 mb-0">Your Order Has Been Placed</h3>
                    <p class="display-6 text-muted">Thank You</p>
                </div>

            </div>
        </div>
        <!-- Project End -->
</section><!-- End Blog Section -->

</main><!-- End #main -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('client.layouts.masterlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\rifat\nubcc-web\resources\views/client/pages/order_confirmed.blade.php ENDPATH**/ ?>