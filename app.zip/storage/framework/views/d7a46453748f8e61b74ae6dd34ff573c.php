

<h3>Hi <?php echo e($Name); ?>,</h3>
<h2 style="color: rgb(250, 123, 5);font-family:Verdana, Geneva, Tahoma, sans-serif;">Congratulations!</h2>
<h3 style="font-family:Verdana, Geneva, Tahoma, sans-serif">Your <?php echo e($Size); ?> Size NUBCC Premium Jercy Order Has Been Confirmed.</h3>
<p style="font-family:Verdana, Geneva, Tahoma, sans-serif;">Thank You.</p>

<span style="font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;display:block;">LOVE_NUB</span>
<span style="font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;display:block;">LOVE_NUBCSE</span>
<span style="font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;display:block;">LOVE_NUBCC</span><?php /**PATH E:\xampp\htdocs\rifat\nubcc-web\resources\views/mail.blade.php ENDPATH**/ ?>