<h1>Congratulation!!! Now you are our NUBCC member.</h1>
<section style="background-color: #eee;">
    <div class="container py-5">
        <div class="row">
            <div class="col-lg-4">
                <div class="card mb-4">
                    <div class="card-body text-center">
                    <img src="<?php echo e(asset('uploads/images/users')); ?>/<?php echo e($data->image); ?>" style="width: 160px; height: 160px; border-radius: 50%;">
                        <h5 class="my-3"><?php echo e($data->username); ?></h5>
                    </div>
                </div>
            </div>
            <div class="col-lg-8">
                <div class="card mb-4">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-sm-3">
                                <p class="mb-0">Full Name</p>
                            </div>
                            <div class="col-sm-9">
                                <p class="text-muted mb-0"><?php echo e($data->username); ?></p>
                            </div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-sm-3">
                                <p class="mb-0">Email</p>
                            </div>
                            <div class="col-sm-9">
                                <p class="text-muted mb-0"><?php echo e($data->email); ?></p>
                            </div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-sm-3">
                                <p class="mb-0">Password</p>
                            </div>
                            <div class="col-sm-9">
                                <p class="text-muted mb-0"><?php echo e($data->password); ?></p>
                            </div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-sm-3">
                                <p class="mb-0">Action</p>
                            </div>
                            <div class="col-sm-9">
                                

                                <form action="<?php echo e(route('user-edit')); ?>" method="get">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="id" value="<?php echo e($data->id); ?>">
                                    <button class="dropdown-item" type="submit"><i class="bx bx-edit-alt me-1"></i> UPDATE</button>
                                </form>
                                <a class="dropdown-item" href="<?php echo e(route('user-logout')); ?>">
                                    <i class="bx bx-power-off me-2"></i>
                                    <span class="align-middle">Log Out</span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><?php /**PATH E:\xampp\htdocs\rifat\nubcc-web\resources\views/userDashboard.blade.php ENDPATH**/ ?>