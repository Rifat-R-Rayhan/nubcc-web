        <!-- Content wrapper -->
        <div class="content-wrapper">

            <!-- Footer -->
            <footer class="content-footer footer bg-footer-theme">
                <div class="container-xxl d-flex flex-wrap justify-content-between py-2 flex-md-row flex-column">
                    <div class="mb-2 mb-md-0">
                        ©copyright
                        <script>
                            document.write(new Date().getFullYear());
                        </script>
                        NUBCC, Developed by
                        <a href="https://themeselection.com" target="_blank" class="footer-link fw-bolder">NUBCC_OFFICIAL</a>
                    </div>
                    <div>
                        <a href="#" class="footer-link me-4" target="_blank">License</a>
                        <a href="#" target="_blank" class="footer-link me-4">Policies</a>
                    </div>
                </div>
            </footer>
            <!-- / Footer -->

            <div class="content-backdrop fade"></div>
        </div>
        <!-- Content wrapper -->