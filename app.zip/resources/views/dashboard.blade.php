@extends('server.layouts.masterlayout')

@section('content')
    @include('server.components.navbar');
    @include('server.components.product-members-statics');
    @include('server.components.balance');
@endsection