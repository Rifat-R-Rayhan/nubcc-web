@extends('client.layouts.masterlayout')

@section('content')
    @include('client.components.slider')
    @include('client.components.about')
    @include('client.components.community')
    @include('client.components.course-news')
    @include('client.components.course-plan')
    @include('client.components.team')
@endsection